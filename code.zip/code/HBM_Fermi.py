# Library
import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit
from scipy import stats
from scipy.optimize import minimize
import copy
from sklearn.mixture import GaussianMixture
from scipy.stats import invgamma
from scipy.stats import gamma
from scipy.stats import norm
import warnings
import pymc3 as pm
import time
import seaborn as sns
import random

warnings.simplefilter('ignore')

# Read Data

path = 'E:\\Yalei_PhD\\pythonscripts'
os.chdir(path)
import datareading
path28 = "E:\\Yalei_PhD\\working data\\Serial28"
confile28 = "E:\\Yalei_PhD\\working data\\Serial28\\MR_IMR_STD1_SER104_ACQ13_ITORIGINAL_PRIMARY_M_DIS2D.con"
datapath28 = "E:\\Yalei_PhD\\working data\\Serial28\\TFL_SR_FIRST-PASS_GAD_0104"
cutsize = [100,180,30,100]

data28 = datareading.datareading(path28,confile28,datapath28,cutsize)

# basic info for analysis

path = "E:\\Yalei_PhD\\working data\\Serial28"
os.chdir(path)
parameter_28_1 = pd.read_csv('p4model_28_1.csv')
parameter_28_2 = pd.read_csv('p4model_28_2.csv')
parameter_28_3 = pd.read_csv('p4model_28_3.csv')

bm_df_28_1 = data28[0]
bm_df_28_2 = data28[1]
bm_df_28_3 = data28[2]
ImagePostContour28 = data28[3]
data_slice_28_1_mc = data28[4]
data_slice_28_2_mc = data28[5]
data_slice_28_3_mc = data28[6]
data_28_1_myo_c = data28[7]
data_28_2_myo_c = data28[8]
data_28_3_myo_c = data28[9]


p_en_x_1 = ImagePostContour28[3,1,1][:,0]
p_en_y_1 = ImagePostContour28[3,1,1][:,1]
p_ep_x_1 = ImagePostContour28[3,1,2][:,0]
p_ep_y_1 = ImagePostContour28[3,1,2][:,1]
p_en_x_2 = ImagePostContour28[2,1,1][:,0]
p_en_y_2 = ImagePostContour28[2,1,1][:,1]
p_ep_x_2 = ImagePostContour28[2,1,2][:,0]
p_ep_y_2 = ImagePostContour28[2,1,2][:,1]
p_en_x_3 = ImagePostContour28[1,1,1][:,0]
p_en_y_3 = ImagePostContour28[1,1,1][:,1]
p_ep_x_3 = ImagePostContour28[1,1,2][:,0]
p_ep_y_3 = ImagePostContour28[1,1,2][:,1]


bp_x_1_min = int(min(ImagePostContour28[3,1,11][:,0]))
bp_x_1_max = int(max(ImagePostContour28[3,1,11][:,0]))
bp_y_1_min = int(min(ImagePostContour28[3,1,11][:,1]))
bp_y_1_max = int(max(ImagePostContour28[3,1,11][:,1]))
bp_x_2_min = int(min(ImagePostContour28[2,1,11][:,0]))
bp_x_2_max = int(max(ImagePostContour28[2,1,11][:,0]))
bp_y_2_min = int(min(ImagePostContour28[2,1,11][:,1]))
bp_y_2_max = int(max(ImagePostContour28[2,1,11][:,1]))
bp_x_3_min = int(min(ImagePostContour28[1,1,11][:,0]))
bp_x_3_max = int(max(ImagePostContour28[1,1,11][:,0]))
bp_y_3_min = int(min(ImagePostContour28[1,1,11][:,1]))
bp_y_3_max = int(max(ImagePostContour28[1,1,11][:,1]))

bp_1 = []
for i in range(1,len(data_slice_28_1_mc)):
    bp_1.append(np.mean(data_slice_28_1_mc[i][bp_y_1_min:bp_y_1_max,bp_x_1_min:bp_x_1_max]))
    
bp_2 = []
for i in range(1,len(data_slice_28_2_mc)):
    bp_2.append(np.mean(data_slice_28_2_mc[i][bp_y_2_min:bp_y_2_max,bp_x_2_min:bp_x_2_max]))
    
bp_3 = []
for i in range(1,len(data_slice_28_3_mc)):
    bp_3.append(np.mean(data_slice_28_3_mc[i][bp_y_3_min:bp_y_3_max,bp_x_3_min:bp_x_3_max]))

myo_1 = {}
for i in range(len(bm_df_28_1[0])):
    temp = []
    for j in range(1,len(bm_df_28_1)):
        temp.append(bm_df_28_1[j]['signal_intensity'][i])
    myo_1[i] = temp

myo_2 = {}
for i in range(len(bm_df_28_2[0])):
    temp = []
    for j in range(1,len(bm_df_28_2)):
        temp.append(bm_df_28_2[j]['signal_intensity'][i])
    myo_2[i] = temp

myo_3 = {}
for i in range(len(bm_df_28_3[0])):
    temp = []
    for j in range(1,len(bm_df_28_3)):
        temp.append(bm_df_28_3[j]['signal_intensity'][i])
    myo_3[i] = temp

#show images

for i in range(len(data_slice_28_2_mc)):
    plt.clf()
    plt.imshow(data_slice_28_2_mc[i],cmap = 'gray')
    plt.scatter(p_ep_x_2,p_ep_y_2, c = 'red', s = 1)
    plt.scatter(p_en_x_2,p_en_y_2, c = 'green', s = 1)
    plt.scatter(bp_x_2_min,bp_y_2_min, c = 'blue', s = 1)
    plt.pause(0.1)

plt.plot(myo_2[0],label = 'healthy tissue')
plt.plot(myo_2[399],label = 'lesion')
plt.plot(bp_1,label = 'blood pool')
plt.xlabel('time')
plt.ylabel('signal intensity')
plt.legend(loc = 'upper mid')

# baseline estimation

def fit(t,p1,p2,p3):
    if (p2-p1) < 0:
        panal = 100
    else:
        panal = 0
    return p2*p3/(p2-p1)*(np.exp(-p1*t)-np.exp(-p2*t)) + panal

ssetau_2 = {}
for tau in range(1,len(bp_2)):
    baseline = np.mean(bp_2[0:tau])
    sseb = np.sum((np.asarray(bp_2[0:tau]) - baseline)**2)
    tnew = np.arange(0,len(bp_2)-tau)
    ynew = bp_2[tau:len(bp_2)] - baseline
    popt , pcov = curve_fit(fit,tnew,ynew,p0=[0.01,0.5,30],bounds = ([0.,0.,0.],[1.,1.,100.]))
    ssem = np.sum((fit(tnew,*popt) - ynew)**2)
    ssetau_2[tau] = sseb+ssem

plt.plot(bp_2)
plt.plot(myo_2[0])

taub_2 = min(ssetau_2,key=ssetau_2.get) 
taumyo_2 = stats.mode(parameter_28_2['tau'])[0][0]

# Fermi estimation

def Fermi(t,A,tau,omega):
    return A/(1+np.exp((t-omega)/tau))

def err(para):
    Fermi = para[0]/(1+np.exp((known[0]-para[2])/para[1]))
    fit = np.convolve(known[1],Fermi)
    fit = fit[0:len(known[0])]
    error = np.linalg.norm(fit-known[2],2)
    return error

Fermipara = []
myofit = []
MBFfit = []
var = []

for i in range(len(myo_2)):
    x = (bp_2[taub_2:25] - np.mean(bp_2[0:taub_2]))#/np.mean(bp_2[0:taub_2])/1736/4.5
    y = (myo_2[i][taumyo_2:taumyo_2+len(x)] - np.mean(myo_2[i][0:taumyo_2]))#/np.mean(bp_2[0:taub_2])/1736/4.5
    t = np.linspace(0,len(x)-1,len(x))
    known = []
    known.append(t)
    known.append(x)
    known.append(y)
    A = 0.1
    tau = 10
    omega = 0.1
    para = [A,tau,omega]
    fit = minimize(err,para, method='SLSQP', bounds = ((0.001,1),(0.1,10),(1,15)), options={'xatol': 1e-12, 'disp': True})
    Fermipara.append(fit.x)
    Fermifit = Fermi(t,*fit.x)
    yfit = np.convolve(Fermifit,x)
    yfit = yfit[0:len(x)]
    var.append(np.var(yfit-y))
    myofit.append(yfit)
    R0 = Fermi(0,*fit.x)
    MBF = R0*60/1.2             ##### ?
    MBFfit.append(MBF)


# estabilish dataframe


MBFdata = copy.deepcopy(bm_df_28_2[0])
MBFdata['signal_intensity'] = MBFfit
MBFdata = MBFdata.rename(columns = {"signal_intensity":"MBF"})
MBFdata['X'] = MBFdata['X'] - 100
MBFdata['Y'] = MBFdata['Y'] - 30
A = []
tau = []
omega = []
for i in range(len(MBFdata)):
    A.append(Fermipara[i][0])
    tau.append(Fermipara[i][1])
    omega.append(Fermipara[i][2])

MBFdata['A'] = A
MBFdata['tau'] = tau
MBFdata['omega'] = omega
MBFdata['var'] = var

# MBF map using Fermi

data_28_2_MBF_c = data_28_2_myo_c[0]
for i in range(len(MBFdata)):
    if MBFdata['MBF'][i] >15:
        data_28_2_MBF_c[MBFdata['X'][i],MBFdata['Y'][i]] = 0
    else:        
        data_28_2_MBF_c[MBFdata['X'][i],MBFdata['Y'][i]] = MBFdata['MBF'][i]


plt.imshow(data_28_2_MBF_c,cmap = 'gray')
plt.colorbar()

# GMM

MBFdata = MBFdata[MBFdata.MBF < 15]
MBFdata.index = np.arange(0,len(MBFdata),1)
gmm = GaussianMixture(2).fit(np.asarray(MBFdata['MBF']).reshape(-1,1))
labels = gmm.predict(np.asarray(MBFdata['MBF']).reshape(-1,1))
MBFdata['Groups'] = labels

if np.mean(MBFdata['MBF'][MBFdata['Groups'] == 0]) > np.mean(MBFdata['MBF'][MBFdata['Groups'] == 1]):
    MBFdata['Groups'] = abs(MBFdata['Groups'] - 1)

data_28_2_MBF_c = np.full((80,70),-1.0)
for i in range(len(MBFdata)):
    data_28_2_MBF_c[MBFdata['X'][i],MBFdata['Y'][i]] = float(MBFdata['Groups'][i])

plt.imshow(data_28_2_MBF_c)
plt.colorbar()

# MCMC random walk setting

varA0 = np.var(MBFdata[MBFdata['Groups'] == 0]['A'])
varA1 = np.var(MBFdata[MBFdata['Groups'] == 1]['A'])
vartau0 = np.var(MBFdata[MBFdata['Groups'] == 0]['tau'])
vartau1 = np.var(MBFdata[MBFdata['Groups'] == 1]['tau'])
varomega0 = np.var(MBFdata[MBFdata['Groups'] == 0]['omega'])
varomega1 = np.var(MBFdata[MBFdata['Groups'] == 1]['omega'])
varA = []
vartau = []
varomega = []
for i in range(len(MBFdata)):
    if labels[i] == 0:
        varA.append(varA0/100)
        vartau.append(vartau0/1000)
        varomega.append(varomega0/1000)
    else:
        varA.append(varA1/100)
        vartau.append(vartau1/1000)
        varomega.append(varomega1/1000)
        
MBFdata['varA'] = varA
MBFdata['vartau'] = vartau
MBFdata['varomega'] = varomega

# HBM function



def multprocessnew(tempdata,beta0,beta1,T,T1,M,t,bloodpool,myocardium,Count,alphaa0,betaa0,alphaa1,betaa1,alphatau0,betatau0,alphatau1,betatau1,alphaomega0,betaomega0,alphaomega1,betaomega1,i):
    varA = tempdata['varA'][i]
    vartau = tempdata['vartau'][i]
    varomega = tempdata['varomega'][i]
    oldgroup = tempdata['Groups'][i]
    Aold = tempdata['A'][i]
    tauold = tempdata['tau'][i]
    omegaold = tempdata['omega'][i]
    count = Count[i]
    alphastar = 0.1
    betastar = 0.1
    if oldgroup == 0:
        alphaa = alphaa0
        betaa = betaa0
        alphatau = alphatau0
        betatau = betatau0
        alphaomega = alphaomega0
        betaomega = betaomega0
    else:
        alphaa = alphaa1
        betaa = betaa1
        alphatau = alphatau1
        betatau = betatau1
        alphaomega = alphaomega1
        betaomega = betaomega1
    Fermiparaold = [Aold,tauold,omegaold]
    Fermifitold = Fermi(t,*Fermiparaold)
    yfitold = np.convolve(Fermifitold,bloodpool)
    yfitold = yfitold[0:M]
    sigmasquare = invgamma.rvs(a = M/2+alphastar,loc = 0, scale = betastar + sum((myocardium[i]-yfitold)**2)/2,size = 1)
    sigmanew = np.sqrt(sigmasquare)
    Anew = Aold + np.random.normal(0,np.sqrt(varA))
    if Anew < 0.001:
        Anew = 0.001 + abs(Anew - 0.001)
    elif Anew > 1:
        Anew = 1 - abs(Anew-1)
    taunew = tauold + np.random.normal(0,np.sqrt(vartau))
    if taunew < 0.1:
        taunew = 0.1 + abs(taunew - 0.1)
    elif taunew > 10:
        taunew = 10 - abs(taunew-10)
    omeganew = omegaold + np.random.normal(0,np.sqrt(varomega))
    if omeganew < 0.1:
        omeganew = 0.1 + abs(omeganew - 0.1)
    elif omeganew > 15:
        omeganew = 15 - abs(omeganew - 15)
    Fermiparanew = [Anew,taunew,omeganew]
    Fermifitnew = Fermi(t,*Fermiparanew)
    yfitnew = np.convolve(Fermifitnew,bloodpool)
    yfitnew = yfitnew[0:M]
    postnew = np.prod(norm.pdf(myocardium[i],loc = yfitnew, scale = sigmanew))*gamma.pdf(Anew,alphaa,loc = 0, scale = 1/betaa)*gamma.pdf(taunew,alphatau,loc=0,scale=1/betatau)*gamma.pdf(omeganew,alphaomega,loc = 0,scale = 1/betaomega)
    postold = np.prod(norm.pdf(myocardium[i],loc = yfitold, scale = sigmanew))*gamma.pdf(Aold,alphaa,loc = 0, scale = 1/betaa)*gamma.pdf(tauold,alphatau,loc=0,scale=1/betatau)*gamma.pdf(omegaold,alphaomega,loc = 0,scale = 1/betaomega) 
    g = 0
    q = 0
    Xi = tempdata['X'][i]
    Yi = tempdata['Y'][i]
    X = np.asarray(tempdata['X'])
    Y = np.asarray(tempdata['Y'])
    group = np.asarray(tempdata['Groups'])
    mbf = np.asarray(tempdata['MBF'])
    MBFold = Fermi(0,*Fermiparaold)*60*1.05 
    MBFnew = Fermi(0,*Fermiparanew)*60*1.05 
    LIST = list(zip(X,Y))
    flag = 0
    if (Xi+1,Yi) in LIST:
        flag = flag + 1
        index = LIST.index((Xi+1,Yi))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)
            q = q - abs(mbf[index]-MBFold)
    if (Xi,Yi+1) in LIST:
        flag = flag + 1
        index = LIST.index((Xi,Yi+1))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)
            q = q - abs(mbf[index]-MBFold)
    if (Xi-1,Yi) in LIST:
        flag = flag + 1
        index = LIST.index((Xi-1,Yi))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)
            q = q - abs(mbf[index]-MBFold)
    if (Xi,Yi-1) in LIST:
        flag = flag + 1
        index = LIST.index((Xi,Yi-1))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)
            q = q - abs(mbf[index]-MBFold)
    if (Xi+2,Yi) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi+2,Yi))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)/2
            q = q - abs(mbf[index]-MBFold)/2
    if (Xi+1,Yi+1) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi+1,Yi+1))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)/2
            q = q - abs(mbf[index]-MBFold)/2
    if (Xi,Yi+2) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi,Yi+2))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)/2
            q = q - abs(mbf[index]-MBFold)/2
    if (Xi-1,Yi+1) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi-1,Yi+1))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)/2
            q = q - abs(mbf[index]-MBFold)/2
    if (Xi-2,Yi) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi-2,Yi))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)/2
            q = q - abs(mbf[index]-MBFold)/2
    if (Xi-1,Yi-1) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi-1,Yi-1))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)/2
            q = q - abs(mbf[index]-MBFold)/2
    if (Xi,Yi-2) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi,Yi-2))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)/2
            q = q - abs(mbf[index]-MBFold)/2
    if (Xi+1,Yi-1) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi+1,Yi-1))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)/2
            q = q - abs(mbf[index]-MBFold)/2
    g = g*4/flag
    q = q*4/flag
    MRFold = np.exp(1/T1*q)
    MRFnew = np.exp(1/T1*g)
    postnew = postnew*MRFnew
    postold = postold*MRFold
    ratio = min(1,postnew/postold)
    u = np.random.uniform(0,1,1)
    if u < ratio:
        Aold = Anew
        tauold = taunew
        omegaold = omeganew
        count = count + 1
    Fermiparaold = [Aold,tauold,omegaold]
    MBFold = Fermi(0,*Fermiparaold)*60*1.05 
    newgroup = abs(oldgroup - 1)
    e = 0
    flag = 0
    if (Xi+1,Yi) in LIST:
        flag = flag + 1
        index = LIST.index((Xi+1,Yi))
        if group[index] == newgroup:
            e = e - beta0
        else:
            e = e + beta0
    if (Xi,Yi+1) in LIST:
        flag = flag + 1
        index = LIST.index((Xi,Yi+1))
        if group[index] == newgroup:
            e = e - beta0
        else:
            e = e + beta0
    if (Xi-1,Yi) in LIST:
        flag = flag + 1
        index = LIST.index((Xi-1,Yi))
        if group[index] == newgroup:
            e = e - beta0
        else:
            e = e + beta0
    if (Xi,Yi-1) in LIST:
        flag = flag + 1
        index = LIST.index((Xi,Yi-1))
        if group[index] == newgroup:
            e = e - beta0
        else:
            e = e + beta0
    if (Xi+2,Yi) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi+2,Yi))
        if group[index] == newgroup:
            e = e - beta1
        else:
            e = e + beta1
    if (Xi+1,Yi+1) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi+1,Yi+1))
        if group[index] == newgroup:
            e = e - beta1
        else:
            e = e + beta1
    if (Xi+1,Yi-1) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi+1,Yi-1))
        if group[index] == newgroup:
            e = e - beta1
        else:
            e = e + beta1
    if (Xi,Yi+2) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi,Yi+2))
        if group[index] == newgroup:
            e = e - beta1
        else:
            e = e + beta1
    if (Xi,Yi-2) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi,Yi-2))
        if group[index] == newgroup:
            e = e - beta1
        else:
            e = e + beta1
    if (Xi-1,Yi+1) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi-1,Yi+1))
        if group[index] == newgroup:
            e = e - beta1
        else:
            e = e + beta1
    if (Xi-1,Yi-1) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi-1,Yi-1))
        if group[index] == newgroup:
            e = e - beta1
        else:
            e = e + beta1
    if (Xi-2,Yi) in LIST:
        flag = flag + 0.5
        index = LIST.index((Xi-2,Yi))
        if group[index] == newgroup:
            e = e - beta1
        else:
            e = e + beta1
    e = e * 4/flag
    postnew = np.exp(-1/T*e)
    postold = np.exp(1/T*e)
    if oldgroup == 0:
        alphaaold = alphaa0
        betaaold = betaa0
        alphatauold = alphatau0
        betatauold = betatau0
        alphaomegaold = alphaomega0
        betaomegaold = betaomega0
    else:
        alphaaold = alphaa1
        betaaold = betaa1
        alphatauold = alphatau1
        betatauold = betatau1
        alphaomegaold = alphaomega1
        betaomegaold = betaomega1
    if newgroup == 0:
        alphaanew = alphaa0
        betaanew = betaa0
        alphataunew = alphatau0
        betataunew = betatau0
        alphaomeganew = alphaomega0
        betaomeganew = betaomega0
    else:
        alphaanew = alphaa1
        betaanew = betaa1
        alphataunew = alphatau1
        betataunew = betatau1
        alphaomeganew = alphaomega1
        betaomeganew = betaomega1
    priorold = gamma.pdf(Aold,alphaaold,loc = 0, scale = 1/betaaold)*gamma.pdf(tauold,alphatauold,loc=0,scale=1/betatauold)*gamma.pdf(omegaold,alphaomegaold,loc = 0,scale = 1/betaomegaold)
    priornew = gamma.pdf(Aold,alphaanew,loc = 0, scale = 1/betaanew)*gamma.pdf(tauold,alphataunew,loc=0,scale=1/betataunew)*gamma.pdf(omegaold,alphaomeganew,loc = 0,scale = 1/betaomeganew)
    postold = postold * priorold
    postnew = postnew * priornew
    ratio = min(1,postnew/postold)
    u = np.random.uniform(0,1,1)
    if u < ratio:
        oldgroup = newgroup  
    return oldgroup,Aold,tauold,omegaold,sigmasquare,MBFold,count


# process HBM given Gamma prior


def multprocessnew(tempdata,beta0,beta1,T,T1,M,t,bloodpool,myocardium,Count,mua0,mua1,vara0,vara1,muomega0,muomega1,varomega0,varomega1,mutau0,mutau1,vartau0,vartau1,i):
    varA = tempdata['varA'][i]
    vartau = tempdata['vartau'][i]
    varomega = tempdata['varomega'][i]
    oldgroup = tempdata['Groups'][i]
    Aold = tempdata['A'][i]
    tauold = tempdata['tau'][i]
    omegaold = tempdata['omega'][i]
    count = Count[i]
    alphastar = 0.1
    betastar = 0.1
    if oldgroup == 0:
        mua = mua0[j]
        vara = vara0[j]
        muomega = muomega0[j]
        varomega = varomega0[j]
        mutau = mutau0[j]
        vartau = vartau0[j]
    else:
        mua = mua1[j]
        vara = vara1[j]
        muomega = muomega1[j]
        varomega = varomega1[j]
        mutau = mutau1[j]
        vartau = vartau1[j]
    Fermiparaold = [Aold,tauold,omegaold]
    Fermifitold = Fermi(t,*Fermiparaold)
    yfitold = np.convolve(Fermifitold,bloodpool)
    yfitold = yfitold[0:M]
    sigmasquare = invgamma.rvs(a = M/2+alphastar,loc = 0, scale = betastar + sum((myocardium[i]-yfitold)**2)/2,size = 1)
    sigmanew = np.sqrt(sigmasquare)
    Anew = Aold + np.random.normal(0,np.sqrt(varA))
    if Anew < 0.001:
        Anew = 0.001 + abs(Anew - 0.001)
    elif Anew > 1:
        Anew = 1 - abs(Anew-1)
    taunew = tauold + np.random.normal(0,np.sqrt(vartau))
    if taunew < 0.1:
        taunew = 0.1 + abs(taunew - 0.1)
    elif taunew > 10:
        taunew = 10 - abs(taunew-10)
    omeganew = omegaold + np.random.normal(0,np.sqrt(varomega))
    if omeganew < 0.1:
        omeganew = 0.1 + abs(omeganew - 0.1)
    elif omeganew > 15:
        omeganew = 15 - abs(omeganew - 15)
    Fermiparanew = [Anew,taunew,omeganew]
    Fermifitnew = Fermi(t,*Fermiparanew)
    yfitnew = np.convolve(Fermifitnew,bloodpool)
    yfitnew = yfitnew[0:M]
    postnew = np.prod(norm.pdf(myocardium[i],loc = yfitnew, scale = sigmanew))*norm.pdf(np.log(Anew), loc = mua, scale = np.sqrt(vara))*norm.pdf(np.log(taunew),loc=mutau,scale=np.sqrt(vartau))*norm.pdf(np.log(omeganew),loc = muomega,scale = np.sqrt(varomega))
    postold = np.prod(norm.pdf(myocardium[i],loc = yfitold, scale = sigmanew))*norm.pdf(np.log(Aold), loc = mua, scale = np.sqrt(vara))*norm.pdf(np.log(tauold),loc=mutau,scale=np.sqrt(vartau))*norm.pdf(np.log(omegaold),loc = muomega,scale = np.sqrt(varomega)) 
    g = 0
    q = 0
    Xi = tempdata['X'][i]
    Yi = tempdata['Y'][i]
    X = np.asarray(tempdata['X'])
    Y = np.asarray(tempdata['Y'])
    group = np.asarray(tempdata['Groups'])
    mbf = np.asarray(tempdata['MBF'])
    MBFold = Fermi(0,*Fermiparaold)*60*1.05 
    MBFnew = Fermi(0,*Fermiparanew)*60*1.05 
    LIST = list(zip(X,Y))
    flag = 0
    if (Xi+1,Yi) in LIST:
        flag = flag + 1
        index = LIST.index((Xi+1,Yi))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)
            q = q - abs(mbf[index]-MBFold)
    if (Xi,Yi+1) in LIST:
        flag = flag + 1
        index = LIST.index((Xi,Yi+1))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)
            q = q - abs(mbf[index]-MBFold)
    if (Xi-1,Yi) in LIST:
        flag = flag + 1
        index = LIST.index((Xi-1,Yi))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)
            q = q - abs(mbf[index]-MBFold)
    if (Xi,Yi-1) in LIST:
        flag = flag + 1
        index = LIST.index((Xi,Yi-1))
        if group[index] == oldgroup:
            g = g - abs(mbf[index]-MBFnew)
            q = q - abs(mbf[index]-MBFold)
    # if (Xi+2,Yi) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi+2,Yi))
    #     if group[index] == oldgroup:
    #         g = g - abs(mbf[index]-MBFnew)/2
    #         q = q - abs(mbf[index]-MBFold)/2
    # if (Xi+1,Yi+1) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi+1,Yi+1))
    #     if group[index] == oldgroup:
    #         g = g - abs(mbf[index]-MBFnew)/2
    #         q = q - abs(mbf[index]-MBFold)/2
    # if (Xi,Yi+2) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi,Yi+2))
    #     if group[index] == oldgroup:
    #         g = g - abs(mbf[index]-MBFnew)/2
    #         q = q - abs(mbf[index]-MBFold)/2
    # if (Xi-1,Yi+1) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi-1,Yi+1))
    #     if group[index] == oldgroup:
    #         g = g - abs(mbf[index]-MBFnew)/2
    #         q = q - abs(mbf[index]-MBFold)/2
    # if (Xi-2,Yi) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi-2,Yi))
    #     if group[index] == oldgroup:
    #         g = g - abs(mbf[index]-MBFnew)/2
    #         q = q - abs(mbf[index]-MBFold)/2
    # if (Xi-1,Yi-1) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi-1,Yi-1))
    #     if group[index] == oldgroup:
    #         g = g - abs(mbf[index]-MBFnew)/2
    #         q = q - abs(mbf[index]-MBFold)/2
    # if (Xi,Yi-2) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi,Yi-2))
    #     if group[index] == oldgroup:
    #         g = g - abs(mbf[index]-MBFnew)/2
    #         q = q - abs(mbf[index]-MBFold)/2
    # if (Xi+1,Yi-1) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi+1,Yi-1))
    #     if group[index] == oldgroup:
    #         g = g - abs(mbf[index]-MBFnew)/2
    #         q = q - abs(mbf[index]-MBFold)/2
    g = g*4/flag
    q = q*4/flag
    MRFold = np.exp(1/T1*q)
    MRFnew = np.exp(1/T1*g)
    postnew = postnew*MRFnew
    postold = postold*MRFold
    ratio = min(1,postnew/postold)
    u = np.random.uniform(0,1,1)
    if u < ratio:
        Aold = Anew
        tauold = taunew
        omegaold = omeganew
        count = count + 1
    Fermiparaold = [Aold,tauold,omegaold]
    MBFold = Fermi(0,*Fermiparaold)*60*1.05 
    newgroup = abs(oldgroup - 1)
    e = 0
    flag = 0
    if (Xi+1,Yi) in LIST:
        flag = flag + 1
        index = LIST.index((Xi+1,Yi))
        if group[index] == newgroup:
            e = e - beta0
        else:
            e = e + beta0
    if (Xi,Yi+1) in LIST:
        flag = flag + 1
        index = LIST.index((Xi,Yi+1))
        if group[index] == newgroup:
            e = e - beta0
        else:
            e = e + beta0
    if (Xi-1,Yi) in LIST:
        flag = flag + 1
        index = LIST.index((Xi-1,Yi))
        if group[index] == newgroup:
            e = e - beta0
        else:
            e = e + beta0
    if (Xi,Yi-1) in LIST:
        flag = flag + 1
        index = LIST.index((Xi,Yi-1))
        if group[index] == newgroup:
            e = e - beta0
        else:
            e = e + beta0
    # if (Xi+2,Yi) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi+2,Yi))
    #     if group[index] == newgroup:
    #         e = e - beta1
    #     else:
    #         e = e + beta1
    # if (Xi+1,Yi+1) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi+1,Yi+1))
    #     if group[index] == newgroup:
    #         e = e - beta1
    #     else:
    #         e = e + beta1
    # if (Xi+1,Yi-1) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi+1,Yi-1))
    #     if group[index] == newgroup:
    #         e = e - beta1
    #     else:
    #         e = e + beta1
    # if (Xi,Yi+2) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi,Yi+2))
    #     if group[index] == newgroup:
    #         e = e - beta1
    #     else:
    #         e = e + beta1
    # if (Xi,Yi-2) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi,Yi-2))
    #     if group[index] == newgroup:
    #         e = e - beta1
    #     else:
    #         e = e + beta1
    # if (Xi-1,Yi+1) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi-1,Yi+1))
    #     if group[index] == newgroup:
    #         e = e - beta1
    #     else:
    #         e = e + beta1
    # if (Xi-1,Yi-1) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi-1,Yi-1))
    #     if group[index] == newgroup:
    #         e = e - beta1
    #     else:
    #         e = e + beta1
    # if (Xi-2,Yi) in LIST:
    #     flag = flag + 0.5
    #     index = LIST.index((Xi-2,Yi))
    #     if group[index] == newgroup:
    #         e = e - beta1
    #     else:
    #         e = e + beta1
    e = e * 4/flag
    postnew = np.exp(-1/T*e)
    postold = np.exp(1/T*e)
    if oldgroup == 0:
        muaold = mua0[j]
        varaold = vara0[j]
        muomegaold = muomega0[j]
        varomegaold = varomega0[j]
        mutauold = mutau0[j]
        vartauold = vartau0[j]
    else:
        muaold = mua1[j]
        varaold = vara1[j]
        muomegaold = muomega1[j]
        varomegaold = varomega1[j]
        mutauold = mutau1[j]
        vartauold = vartau1[j]
    if newgroup == 0:
        muanew = mua0[j]
        varanew = vara0[j]
        muomeganew = muomega0[j]
        varomeganew = varomega0[j]
        mutaunew = mutau0[j]
        vartaunew = vartau0[j]
    else:
        muanew = mua1[j]
        varanew = vara1[j]
        muomeganew = muomega1[j]
        varomeganew = varomega1[j]
        mutaunew = mutau1[j]
        vartaunew = vartau1[j]
    priorold = norm.pdf(np.log(Aold),loc = muaold, scale = np.sqrt(varaold))*norm.pdf(np.log(tauold),loc=mutauold,scale=np.sqrt(vartauold))*norm.pdf(np.log(omegaold),loc = muomegaold,scale = np.sqrt(varomegaold))
    priornew = norm.pdf(np.log(Aold),loc = muanew, scale = np.sqrt(varanew))*norm.pdf(np.log(tauold),loc=mutaunew,scale=np.sqrt(vartaunew))*norm.pdf(np.log(omegaold),loc = muomeganew,scale = np.sqrt(varomeganew))
    postold = postold * priorold
    postnew = postnew * priornew 
    ratio = min(1,postnew/postold)
    u = np.random.uniform(0,1,1)
    if u < ratio:
        oldgroup = newgroup  
    return oldgroup,Aold,tauold,omegaold,sigmasquare,MBFold,count

# process HBM given log Gaussian prior (Gamma prior is annotated)

start = time.clock()
tempdata = copy.deepcopy(MBFdata)  
bloodpool = bp_2[taub_2:25] - np.mean(bp_2[0:taub_2])
myocardium = {}
for i in range(len(myo_2)):
    myocardium[i] = myo_2[i][taumyo_2:taumyo_2+len(bloodpool)] - np.mean(myo_2[i][0:taumyo_2])
M = len(bloodpool)
t = np.linspace(0,M-1,M)
mua0p = 0
vara0p = 10
muomega0p = 0
varomega0p = 10
mutau0p = 0
vartau0p = 10
mua1p = 0
vara1p = 10
muomega1p = 0
varomega1p = 10
mutau1p = 0
vartau1p = 10
alphaa0p = 0.1
betaa0p = 0.1
alphaa1p = 0.1
betaa1p = 0.1
alphatau0p = 0.1
betatau0p = 0.1
alphatau1p = 0.1
betatau1p = 0.1
alphaomega0p = 0.1
betaomega0p = 0.1
alphaomega1p = 0.1
betaomega1p = 0.1
beta0 = 1
beta1 = 0.5
T = 0.1
T1 = 1
group = {}
A = {}
tau = {}
omega = {}
MBF = {}
var = {}
mua0 = []
mua1 = []
vara0 = []
vara1 = []
muomega0 = []
muomega1 = []
varomega0 = []
varomega1 = []
mutau0 = []
mutau1 = []
vartau0 = []
vartau1 = []
# alphaa0 = []
# betaa0 = []
# alphatau0 = []
# betatau0 = []
# alphaomega0 = []
# betaomega0 = []
# alphaa1 = []
# betaa1 = []
# alphatau1 = []
# betatau1 = []
# alphaomega1 = []
# betaomega1 = []
iterations = 10000
burnin = 5000
Count = np.zeros(len(tempdata))
changetime = 100
changepoint = np.arange(100,iterations+burnin,100)
mua0.append(mua0p)
mua1.append(mua1p)
vara0.append(vara0p)
vara1.append(vara1p)
muomega0.append(muomega0p) 
muomega1.append(muomega1p)
varomega0.append(varomega0p) 
varomega1.append(varomega1p)
mutau0.append(mutau0p)
mutau1.append(mutau1p)
vartau0.append(vartau0p)
vartau1.append(vartau1p)
# alphaa0.append(alphaa0p)
# alphaa1.append(alphaa1p)
# alphatau0.append(alphatau0p)
# alphatau1.append(alphatau1p)
# alphaomega0.append(alphaomega0p)
# alphaomega1.append(alphaomega1p)
# betaa0.append(betaa0p)
# betaa1.append(betaa1p)
# betatau0.append(betatau0p)
# betatau1.append(betatau1p)
# betaomega0.append(betaomega0p)
# betaomega1.append(betaomega1p)
for j in range(iterations+burnin):
    grouplist = []
    Alist = []
    taulist = []
    omegalist = []
    varlist = []
    MBFlist = []
    results = []
    time1 = time.clock()
    for i in range(len(tempdata)):
        results.append(multprocessnew(tempdata,beta0,beta1,T,T1,M,t,bloodpool,myocardium,Count,mua0,mua1,vara0,vara1,muomega0,muomega1,varomega0,varomega1,mutau0,mutau1,vartau0,vartau1,i))
        Count[i] = results[i][6]
    # results.append(Parallel(n_jobs=num_cores)(delayed(multprocessnew)(tempdata,beta0,beta1,T,T1,M,t,bloodpool,myocardium,Count,muk0,muk1,vark0,vark1,i) for i in range(len(MBFdata))))
    time2 = time.clock()
    print(time2 - time1)
    print(j)
    for i in range(len(MBFdata)):
        grouplist.append(results[i][0])
        Alist.append(float(results[i][1]))
        taulist.append(float(results[i][2]))
        omegalist.append(float(results[i][3]))
        varlist.append(float(results[i][4]))
        MBFlist.append(float(results[i][5]))
        group[j,i] = results[i][0]
        A[j,i] = float(results[i][1])
        tau[j,i] = float(results[i][2])
        omega[j,i] = float(results[i][3])
        var[j,i] = float(results[i][4])
        MBF[j,i] = float(results[i][5])
        Count[i] = float(results[i][6])
    tempdata['Groups'] = grouplist
    tempdata['A'] = Alist
    tempdata['tau'] = taulist
    tempdata['omega'] = omegalist
    tempdata['var'] = varlist
    tempdata['MBF'] = MBFlist
    if j in changepoint:
        varA = np.asarray(tempdata['varA'])
        vartau = np.asarray(tempdata['vartau'])
        varomega = np.asarray(tempdata['varomega'])
        for i in range(len(tempdata)):
            ratio = Count[i]/100
            if ratio > 0.44:
                varA[i] = varA[i]*1.5
                vartau[i] = vartau[i]*1.5
                varomega[i] = varomega[i]*1.5
            elif ratio < 0.23:
                varA[i] = varA[i]/1.5
                vartau[i] = vartau[i]/1.5
                varomega[i] = varomega[i]/1.5
        tempdata['varA'] = varA
        tempdata['vartau'] = vartau
        tempdata['varomega'] = varomega
        Count = np.zeros(len(tempdata))
    N0 = len(tempdata[tempdata['Groups'] == 0]['A'])
    N1 = len(tempdata[tempdata['Groups'] == 1]['A'])
    Ba0 = vara0[j] + N0*vara0p
    Ca0 = vara0[j]*mua0p + vara0p*sum(np.log(tempdata[tempdata['Groups'] == 0]['A']))
    Da0 = vara0[j]*vara0p
    mua0.append(np.random.normal(Ca0/Ba0,Da0/Ba0,1))
    Btau0 = vartau0[j] + N0*vartau0p
    Ctau0 = vartau0[j]*mutau0p + vartau0p*sum(np.log(np.asarray(tempdata[tempdata['Groups'] == 0]['tau'])))
    Dtau0 = vartau0[j]*vartau0p
    mutau0.append(np.random.normal(Ctau0/Btau0,Dtau0/Btau0,1))
    Bomega0 = varomega0[j] + N0*varomega0p
    Comega0 = varomega0[j]*muomega0p + varomega0p*sum(np.log(tempdata[tempdata['Groups'] == 0]['omega']))
    Domega0 = varomega0[j]*varomega0p
    muomega0.append(np.random.normal(Comega0/Bomega0,Domega0/Bomega0,1))
    Ba1 = vara1[j] + N1*vara1p
    Ca1 = vara1[j]*mua1p + vara1p*sum(np.log(tempdata[tempdata['Groups'] == 1]['A']))
    Da1 = vara1[j]*vara1p
    mua1.append(np.random.normal(Ca1/Ba1,Da1/Ba1,1))
    Btau1 = vartau1[j] + N1*vartau1p
    Ctau1 = vartau1[j]*mutau1p + vartau1p*sum(np.log(tempdata[tempdata['Groups'] == 1]['tau']))
    Dtau1 = vartau1[j]*vartau1p
    mutau1.append(np.random.normal(Ctau1/Btau1,Dtau1/Btau1,1))
    Bomega1 = varomega1[j] + N1*varomega1p
    Comega1 = varomega1[j]*muomega1p + varomega1p*sum(np.log(tempdata[tempdata['Groups'] == 1]['omega']))
    Domega1 = varomega1[j]*varomega1p
    muomega1.append(np.random.normal(Comega1/Bomega1,Domega1/Bomega1,1))
    vara0.append(invgamma.rvs(a = N0/2+alphaa0p,loc = 0, scale = betaa0p + sum((np.log(tempdata[tempdata['Groups'] == 0]['A'])-mua0[j+1])**2)/2,size = 1))
    vara1.append(invgamma.rvs(a = N1/2+alphaa1p,loc = 0, scale = betaa1p + sum((np.log(tempdata[tempdata['Groups'] == 1]['A'])-mua1[j+1])**2)/2,size = 1))
    vartau0.append(invgamma.rvs(a = N0/2+alphatau0p,loc = 0, scale = betatau0p + sum((np.log(tempdata[tempdata['Groups'] == 0]['tau'])-mutau0[j+1])**2)/2,size = 1))
    vartau1.append(invgamma.rvs(a = N1/2+alphatau1p,loc = 0, scale = betatau1p + sum((np.log(tempdata[tempdata['Groups'] == 1]['tau'])-mutau1[j+1])**2)/2,size = 1))
    varomega0.append(invgamma.rvs(a = N0/2+alphaomega0p,loc = 0, scale = betaomega0p + sum((np.log(tempdata[tempdata['Groups'] == 0]['omega'])-muomega0[j+1])**2)/2,size = 1))
    varomega1.append(invgamma.rvs(a = N1/2+alphaomega1p,loc = 0, scale = betaomega1p + sum((np.log(tempdata[tempdata['Groups'] == 1]['omega'])-muomega1[j+1])**2)/2,size = 1))
    # alphaa0sum = 0.01 + len(tempdata[tempdata['Groups'] == 0]['A'])
    # betaa0sum = 0.01 + np.sum(tempdata[tempdata['Groups'] == 0]['A'])
    # betaa0 = gamma.rvs(alphaa0sum, loc=0, scale=1/betaa0sum, size=1)
    # alphaa1sum = 0.01 + len(tempdata[tempdata['Groups'] == 1]['A'])
    # betaa1sum = 0.01 + np.sum(tempdata[tempdata['Groups'] == 1]['A'])
    # betaa1 = gamma.rvs(alphaa1sum, loc=0, scale=1/betaa1sum, size=1)
    # alphaomega0sum = 0.01 + len(tempdata[tempdata['Groups'] == 0]['omega'])
    # betaomega0sum = 0.01 + np.sum(tempdata[tempdata['Groups'] == 0]['omega'])
    # betaomega0 = gamma.rvs(alphaomega0sum, loc=0, scale=1/betaomega0sum, size=1)
    # alphaomega1sum = 0.01 + len(tempdata[tempdata['Groups'] == 1]['omega'])
    # betaomega1sum = 0.01 + np.sum(tempdata[tempdata['Groups'] == 1]['omega'])
    # betaomeag1 = gamma.rvs(alphaomega1sum, loc=0, scale=1/betaomega1sum, size=1)
    # alphatau0sum = 0.01 + len(tempdata[tempdata['Groups'] == 0]['tau'])
    # betatau0sum = 0.01 + np.sum(tempdata[tempdata['Groups'] == 0]['tau'])
    # betatau0 = gamma.rvs(alphatau0sum, loc=0, scale=1/betatau0sum, size=1)
    # alphatau1sum = 0.01 + len(tempdata[tempdata['Groups'] == 1]['tau'])
    # betatau1sum = 0.01 + np.sum(tempdata[tempdata['Groups'] == 1]['tau'])
    # betatau1 = gamma.rvs(alphatau1sum, loc=0, scale=1/betatau1sum, size=1)
    # alphaa0new = abs(alphaa0 + np.random.normal(0,1))
    # alphaomega0new = abs(alphaomega0 + np.random.normal(0,1))
    # alphatau0new = abs(alphatau0 + np.random.normal(0,1))
    # alphaa1new = abs(alphaa1 + np.random.normal(0,1))
    # alphaomega1new = abs(alphaomega1 + np.random.normal(0,1))
    # alphatau1new = abs(alphatau1 + np.random.normal(0,1))
    # proda0 = gamma.pdf(alphaa0,0.01,loc = 0, scale = 1/0.01)
    # proda1 = gamma.pdf(alphaa1,0.01,loc = 0, scale = 1/0.01)
    # proda0new = gamma.pdf(alphaa0new,0.01,loc = 0, scale = 1/0.01)
    # proda1new = gamma.pdf(alphaa1new,0.01,loc = 0, scale = 1/0.01)
    # prodtau0 = gamma.pdf(alphatau0,0.01,loc = 0, scale = 1/0.01)
    # prodtau1 = gamma.pdf(alphatau1,0.01,loc = 0, scale = 1/0.01)
    # prodtau0new = gamma.pdf(alphatau0new,0.01,loc = 0, scale = 1/0.01)
    # prodtau1new = gamma.pdf(alphatau1new,0.01,loc = 0, scale = 1/0.01)
    # prodomega0 = gamma.pdf(alphaomega0,0.01,loc = 0, scale = 1/0.01)
    # prodomega1 = gamma.pdf(alphaomega1,0.01,loc = 0, scale = 1/0.01)
    # prodomega0new = gamma.pdf(alphaomega0new,0.01,loc = 0, scale = 1/0.01)
    # prodomega1new = gamma.pdf(alphaomega1new,0.01,loc = 0, scale = 1/0.01)
    # for i in range(len(tempdata)):
    #     if grouplist[i] == 0:
    #         proda0 = proda0 * gamma.pdf(Alist[i],alphaa0,loc = 0, scale = 1/betaa0)
    #         prodtau0 = prodtau0 * gamma.pdf(taulist[i],alphatau0,loc = 0, scale = 1/betatau0)
    #         prodomega0 = prodomega0 * gamma.pdf(omegalist[i],alphaomega0,loc = 0, scale = 1/betaomega0)
    #     else:
    #         proda0new = proda0new * gamma.pdf(Alist[i],alphaa0new,loc = 0, scale = 1/betaa0)
    #         prodtau0new = prodtau0new * gamma.pdf(taulist[i],alphatau0new,loc = 0, scale = 1/betatau0)
    #         prodomega0new = prodomega0new * gamma.pdf(omegalist[i],alphaomega0new,loc = 0, scale = 1/betaomega0)
    #     if grouplist[i] == 1:
    #         proda1 = proda1 * gamma.pdf(Alist[i],alphaa1,loc = 0, scale = 1/betaa1)
    #         prodtau1 = prodtau1 * gamma.pdf(taulist[i],alphatau1,loc = 0, scale = 1/betatau1)
    #         prodomega1 = prodomega1 * gamma.pdf(omegalist[i],alphaomega1,loc = 0, scale = 1/betaomega1)
    #     else:
    #         proda1new = proda1new * gamma.pdf(Alist[i],alphaa1new,loc = 0, scale = 1/betaa1)
    #         prodtau1new = prodtau1new * gamma.pdf(taulist[i],alphatau1new,loc = 0, scale = 1/betatau1)
    #         prodomega1new = prodomega1new * gamma.pdf(omegalist[i],alphaomega1new,loc = 0, scale = 1/betaomega1)
    # ratio = min(1,proda0/proda0new)
    # u = np.random.uniform(0,1,1)
    # if u < ratio:
    #     alphaa0 = alphaa0new
    # ratio = min(1,prodtau0/prodtau0new)
    # u = np.random.uniform(0,1,1)
    # if u < ratio:
    #     alphatau0 = alphatau0new
    # ratio = min(1,prodomega0/prodomega0new)
    # u = np.random.uniform(0,1,1)
    # if u < ratio:
    #     alphaomega0 = alphaomega0new
    # ratio = min(1,proda1/proda1new)
    # u = np.random.uniform(0,1,1)
    # if u < ratio:
    #     alphaa1 = alphaa1new
    # ratio = min(1,prodtau1/prodtau1new)
    # u = np.random.uniform(0,1,1)
    # if u < ratio:
    #     alphatau1 = alphatau1new
    # ratio = min(1,prodomega1/prodomega1new)
    # u = np.random.uniform(0,1,1)
    # if u < ratio:
    #     alphaomega1 = alphaomega1new
end = time.clock()
elapsed = end - start
print(elapsed/3600)


# results analysis

pixelgroup = np.zeros(len(MBFdata))
for i in range(len(MBFdata)):
    for j in  range(burnin, iterations + burnin):
        pixelgroup[i] = pixelgroup[i] + group[j,i]
    pixelgroup[i] = pixelgroup[i]/iterations

resultsss = copy.deepcopy(tempdata)  
resultsss['Groups'] = pixelgroup
  
data_28_2_MBF_c = np.full((80,70),-1.0)
for i in range(len(resultsss)):
    data_28_2_MBF_c[resultsss['X'][i],resultsss['Y'][i]] = float(resultsss['Groups'][i])

plt.imshow(data_28_2_MBF_c)
# sns.heatmap(data_28_2_MBF_c)
plt.colorbar()


MBFgroup = np.zeros(len(MBFdata))
for i in range(len(MBFdata)):
    for j in range(burnin, iterations + burnin):
        MBFgroup[i] = MBFgroup[i] + MBF[j,i]
    MBFgroup[i] = MBFgroup[i]/iterations

resultsss['MBF'] = MBFgroup

data_28_2_MBF_c = np.full((80,70),-1.0) 
for i in range(len(resultsss)):
    data_28_2_MBF_c[resultsss['X'][i],resultsss['Y'][i]] = float(resultsss['MBF'][i])

plt.imshow(data_28_2_MBF_c,cmap='gray')
plt.colorbar()


t01mbf187 = np.zeros(iterations+burnin)
t01mbf767 = np.zeros(iterations+burnin)
t01mbf399 = np.zeros(iterations+burnin)
t01mbf16 = np.zeros(iterations+burnin)
for i in range(iterations+burnin):
    t01mbf399[i] = MBF[i,399]
    t01mbf16[i] = MBF[i,16]
    t01mbf767[i] = MBF[i,767]
    t01mbf187[i] = MBF[i,187]

t01trace  = {'mbf399':t01mbf399,'mbf16':t01mbf16,'mbf187':t01mbf187,'mbf767':t01mbf767}

pm.traceplot(t01trace,var_names = ['mbf399','mbf16','mbf187','mbf767'])


t01mbf187 = np.zeros(iterations)
t01mbf767 = np.zeros(iterations)
t01mbf399 = np.zeros(iterations)
t01mbf16 = np.zeros(iterations)
for i in range(burnin, iterations+burnin):
    t01mbf399[i-burnin] = MBF[i,399]
    t01mbf16[i-burnin] = MBF[i,16]
    t01mbf767[i-burnin] = MBF[i,767]
    t01mbf187[i-burnin] = MBF[i,187]

t01trace  = {'mbf399':t01mbf399,'mbf16':t01mbf16,'mbf187':t01mbf187,'mbf767':t01mbf767}

pm.traceplot(t01trace,var_names = ['mbf399','mbf16','mbf187','mbf767'])


t01A187 = np.zeros(iterations)
t01tau187 = np.zeros(iterations)
t01omega187 = np.zeros(iterations)
for i in range(burnin, iterations+burnin):
    t01A187[i-burnin] = A[i,187]
    t01tau187[i-burnin] = tau[i,187]
    t01omega187[i-burnin] = omega[i,187]


t01trace  = {'A187':t01A187,'tau187':t01tau187,'omega187':t01omega187}

pm.traceplot(t01trace,var_names = ['A187','tau187','omega187'])

t01A399 = np.zeros(iterations)
t01tau399 = np.zeros(iterations)
t01omega399 = np.zeros(iterations)
t01var399 = np.zeros(iterations)
for i in range(burnin, iterations+burnin):
    t01A399[i-burnin] = A[i,399]
    t01tau399[i-burnin] = tau[i,399]
    t01omega399[i-burnin] = omega[i,399]
    t01var399[i-burnin] = var[i,399]

t01trace  = {'A399':t01A399,'tau399':t01tau399,'omega399':t01omega399}

pm.traceplot(t01trace,var_names = ['A399','tau399','omega399'])


mua399 = mua0[10000]
vara399 = vara0[10000]
a399prior = np.random.normal(np.exp(mua399),vara399,1000)
loga = np.log(a399prior)

sns.distplot(t01A399, hist=False, kde=True,label = 'posterior')
sns.distplot(a399prior, hist=False, kde=True, label = 'prior')
plt.legend()
plt.xlabel('$A_{399}$')
plt.ylabel('Density')
plt.ylim([-1, 120])
plt.title('The kernel Density of posterior and prior distributions of $A_{399}$')

muaprior = np.random.normal(0,10,1000)
mua0f = np.asarray(mua0)
for i in range(len(mua0f)-1):
    mua0f[i+1] = mua0f[i+1][0]
mua0ff = mua0f.astype(float)
sns.distplot(mua0ff, hist=False, kde=True,label = 'posterior')
sns.distplot(muaprior, hist=False, kde=True, label = 'prior')
plt.legend()
plt.xlabel('$\mu_{A_{399}}$')
plt.ylabel('Density')
plt.ylim([-0.1, 13])
plt.title('The kernel Density of posterior and prior distributions of $\mu_{A_{399}}$')

varprior = invgamma.rvs(0.1,0.1,size =1000)

sns.distplot(np.log(t01var399), hist=False, kde=True,label = 'posterior')
sns.distplot(np.log(varprior), hist=False, kde=True, label = 'prior')
plt.legend()
plt.xlabel('$\sigma_{399}^{2}$')
plt.ylabel('Density')
plt.ylim([-0.02, 1.2])
plt.title('The kernel Density of posterior and prior distributions of $\sigma_{399}^{2}$')

tips = sns.load_dataset("tips")

Astd = random.sample(list(t01A399),1000)
Astd = (Astd - np.mean(Astd))/np.sqrt(np.var(Astd))
tautd = random.sample(list(t01tau399),1000)
tautd = (tautd - np.mean(tautd))/np.sqrt(np.var(tautd))
omegatd = random.sample(list(t01omega399),1000)
omegatd = (omegatd - np.mean(omegatd))/np.sqrt(np.var(omegatd))
vartd = random.sample(list(t01var399),1000)
vartd = (vartd - np.mean(vartd))/np.sqrt(np.var(vartd))

data = pd.DataFrame({'A':Astd, '$\omega$':omegatd, '\u03C4':tautd, 'Variance of A':vartd})
data = data.melt()

sns.violinplot(data=data, y='value', split=True,  x='variable')

data = pd.DataFrame({'posterior':random.sample(list(np.log(mua0ff+4)),1000), 'prior':np.log(muaprior+1)})
data = data.melt()
data['name'] = 'logrithm of $\mu_{A}+1$'

sns.violinplot(data=data, y='value', split=True, hue='variable', x='name')

data = pd.DataFrame({'posterior':random.sample(list(np.log(t01var399)),1000), 'prior':np.log(varprior)})
data = data.melt()
data['name'] = 'logrithm of Var'

sns.violinplot(data=data, y='value', split=True, x='variable')

score399A = pm.geweke(t01A399)
score399tau = pm.geweke(t01tau399)
score399omega = pm.geweke(t01omega399)
plt.plot(score399A[:,1],label = 'A')
plt.plot(score399tau[:,1],label = 'tau')
plt.plot(score399omega[:,1],label = 'omega')
plt.axhline(1, c='red')
plt.axhline(-1, c='red')
plt.legend()
plt.title('Geweke score')



score399 = pm.geweke(t01mbf399)
score16 = pm.geweke(t01mbf16)
score187 = pm.geweke(t01mbf187)
score767 = pm.geweke(t01mbf767)



plt.plot(score399[:,1],label = '399')
plt.plot(score16[:,1],label = '16')
plt.plot(score187[:,1],label = '187')
plt.plot(score767[:,1],label = '767')
plt.axhline(1, c='red')
plt.axhline(-1, c='red')
plt.legend()
plt.title('Geweke score')


t01meanA = []
t01meantau = []
t01meanomega = []
t01meanll = []
t01meanvar = []
for i in range(len(MBFdata)):
    tempA = 0
    temptau = 0
    tempomega = 0
    templl = 0
    tempvar = 0
    print(i)
    for j in range(burnin, iterations + burnin):
        tempvar = tempvar + var[j,i]
        tempA = tempA + A[j,i]
        temptau = temptau + tau[j,i]
        tempomega = tempomega + omega[j,i]
        Fermipara = [A[j,i],tau[j,i],omega[j,i]]
        Fermifit = Fermi(t,*Fermipara)
        yfit = np.convolve(Fermifit,bloodpool)
        yfit = yfit[0:M]
        templl = templl + np.log(np.prod(norm.pdf(myocardium[i],loc = yfit, scale = var[j,i])))
    t01meanA.append(tempA/iterations)
    t01meantau.append(temptau/iterations)
    t01meanomega.append(tempomega/iterations)
    t01meanll.append(templl/iterations)
    t01meanvar.append(tempvar/iterations)


lppd = 0
pwaic = 0
for i in range(len(MBFdata)):
    templppd = 0
    temp = []
    for j in range(burnin, iterations + burnin):
        Fermipara = [A[j,i],tau[j,i],omega[j,i]]
        Fermifit = Fermi(t,*Fermipara)
        yfit = np.convolve(Fermifit,bloodpool)
        yfit = yfit[0:M]
        templppd = templppd + np.prod(norm.pdf(myocardium[i],loc = yfit, scale = var[j,i]))
        temp.append(np.log(np.prod(norm.pdf(myocardium[i],loc = yfit, scale = var[j,i]))))
    lppd = lppd + np.log(templppd/iterations)
    pwaic = pwaic + np.var(temp)
    print(i)

WAIC = -2*(lppd - pwaic)
print(WAIC)









