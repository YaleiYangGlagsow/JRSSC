import os
import numpy as np
import cv2
import pydicom
import copy
import pandas as pd
def datareading(path,confile,datapath,cutsize):
    os.chdir(path)
    ImagePostContour = {}
    ImagePostPoint = {}
    con = open(confile,"r")
    line = con.readline()
    while len(line) > 0:
        line = con.readline()
        if '[XYCONTOUR]' in line:
            line = con.readline()
            slicePhase = int(line.split()[0]) + 1
            imagePhase = int(line.split()[1]) + 1
            contourNumber = int(line.split()[2]) + 1
            line = con.readline()
            lineNumber = int(line)
            xycontour = np.zeros((lineNumber,2))
            for i in range(lineNumber):
                line = con.readline()
                xycontour[i,0] = line.split()[0]
                xycontour[i,1] = line.split()[1]
            ImagePostContour[(slicePhase,imagePhase,contourNumber)] = xycontour
        if '[POINT]' in line:
            line = con.readline()
            imagePhase = int(line.split()[1]) + 1
            line = con.readline()
            xypoint = np.zeros(2)
            xypoint[0] = line.split()[0]
            xypoint[1] = line.split()[1]
            ImagePostPoint[imagePhase] = xypoint
    length_image = len(ImagePostPoint)    
    motioncorrection = {}
    motioncorrection[1] = np.zeros((length_image,2))
    motioncorrection[2] = np.zeros((length_image,2))
    motioncorrection[3] = np.zeros((length_image,2))
    for i in range(length_image):
        motioncorrection[1][i,0] = ImagePostContour[3,i+1,1][0,0]
        motioncorrection[1][i,1] = ImagePostContour[3,i+1,1][0,1]
        motioncorrection[2][i,0] = ImagePostContour[2,i+1,1][0,0]
        motioncorrection[2][i,1] = ImagePostContour[2,i+1,1][0,1]
        motioncorrection[3][i,0] = ImagePostContour[1,i+1,1][0,0]
        motioncorrection[3][i,1] = ImagePostContour[1,i+1,1][0,1]
    motioncorrection[1][:,0] = motioncorrection[1][:,0] - motioncorrection[1][0,0]
    motioncorrection[1][:,1] = motioncorrection[1][:,1] - motioncorrection[1][0,1]
    motioncorrection[2][:,0] = motioncorrection[2][:,0] - motioncorrection[2][0,0]
    motioncorrection[2][:,1] = motioncorrection[2][:,1] - motioncorrection[2][0,1]
    motioncorrection[3][:,0] = motioncorrection[3][:,0] - motioncorrection[3][0,0]
    motioncorrection[3][:,1] = motioncorrection[3][:,1] - motioncorrection[3][0,1]
    os.chdir(datapath)
    data = [1]*len(os.listdir(os.getcwd()))
    filename = os.listdir(os.getcwd())
    for i in range(len(filename)):
        data[i] = pydicom.dcmread(filename[i])
    data_slice_1 = [1]*(len(data)//4)
    data_slice_2 = [1]*(len(data)//4)
    data_slice_3 = [1]*(len(data)//4)
    for i in np.arange(0,len(data),4):
        j = i//4
        data_slice_1[j] = data[i]
        data_slice_2[j] = data[i+1]
        data_slice_3[j] = data[i+2]
    mc_x_1 = motioncorrection[1][:,0]
    mc_y_1 = motioncorrection[1][:,1]
    mc_x_2 = motioncorrection[2][:,0]
    mc_y_2 = motioncorrection[2][:,1]
    mc_x_3 = motioncorrection[3][:,0]
    mc_y_3 = motioncorrection[3][:,1]
    p_en_x_1 = [1]*len(mc_x_1)
    p_en_y_1 = [1]*len(mc_x_1)
    p_ep_x_1 = [1]*len(mc_x_1)
    p_ep_y_1 = [1]*len(mc_x_1)
    p_en_x_2 = [1]*len(mc_x_2)
    p_en_y_2 = [1]*len(mc_x_2)
    p_ep_x_2 = [1]*len(mc_x_2)
    p_ep_y_2 = [1]*len(mc_x_2)  
    p_en_x_3 = [1]*len(mc_x_3)
    p_en_y_3 = [1]*len(mc_x_3)
    p_ep_x_3 = [1]*len(mc_x_3)
    p_ep_y_3 = [1]*len(mc_x_3)
    data_slice_1_mc = [1]*len(data_slice_1)
    data_slice_2_mc = [1]*len(data_slice_2)
    data_slice_3_mc = [1]*len(data_slice_3)
    for i in range(len(data_slice_1)):
        rows,cols = data_slice_1[i].pixel_array.shape
        M = np.float32([[1,0,-mc_x_1[i]],[0,1,-mc_y_1[i]]])
        data_slice_1_mc[i] = cv2.warpAffine(data_slice_1[i].pixel_array,M,(cols,rows))    
    for i in range(len(data_slice_2)):
        rows,cols = data_slice_2[i].pixel_array.shape
        M = np.float32([[1,0,-mc_x_2[i]],[0,1,-mc_y_2[i]]])
        data_slice_2_mc[i] = cv2.warpAffine(data_slice_2[i].pixel_array,M,(cols,rows))  
    for i in range(len(data_slice_3)):
        rows,cols = data_slice_3[i].pixel_array.shape
        M = np.float32([[1,0,-mc_x_3[i]],[0,1,-mc_y_3[i]]])
        data_slice_3_mc[i] = cv2.warpAffine(data_slice_3[i].pixel_array,M,(cols,rows))
    data1_en = copy.deepcopy(data_slice_1_mc)
    p_en_x_1 = ImagePostContour[3,1,1][:,0]
    p_en_y_1 = ImagePostContour[3,1,1][:,1]
    p_ep_x_1 = ImagePostContour[3,1,2][:,0]
    p_ep_y_1 = ImagePostContour[3,1,2][:,1]
    p_en_x_2 = ImagePostContour[2,1,1][:,0]
    p_en_y_2 = ImagePostContour[2,1,1][:,1]
    p_ep_x_2 = ImagePostContour[2,1,2][:,0]
    p_ep_y_2 = ImagePostContour[2,1,2][:,1]
    p_en_x_3 = ImagePostContour[1,1,1][:,0]
    p_en_y_3 = ImagePostContour[1,1,1][:,1]
    p_ep_x_3 = ImagePostContour[1,1,2][:,0]
    p_ep_y_3 = ImagePostContour[1,1,2][:,1]
    for i in range(len(data1_en)):
        for j in range(len(data1_en[0][0,])):
            for k in range(len(data1_en[0])):
                if (float(j) == np.floor(p_en_x_1)).any():
                    if (k > np.min(np.floor(p_en_y_1[np.where(np.floor(p_en_x_1) == float(j))]))) and (k < np.max(np.floor(p_en_y_1[np.where(np.floor(p_en_x_1) == float(j))]))):
                        data1_en[i][k,j] = data1_en[i][k,j] + 1
                    else:
                        data1_en[i][k,j] = 0
                else:
                    data1_en[i][k,j] = 0
    data2_en = copy.deepcopy(data_slice_2_mc)  
    for i in range(len(data2_en)):
        for j in range(len(data2_en[0][0,])):
            for k in range(len(data2_en[0])):
                if (float(j) == np.floor(p_en_x_2)).any():
                    if (k > np.min(np.floor(p_en_y_2[np.where(np.floor(p_en_x_2) == float(j))]))) and (k < np.max(np.floor(p_en_y_2[np.where(np.floor(p_en_x_2) == float(j))]))):
                        data2_en[i][k,j] = data2_en[i][k,j] + 1
                    else:
                        data2_en[i][k,j] = 0
                else:
                    data2_en[i][k,j] = 0  
    data3_en = copy.deepcopy(data_slice_3_mc)  
    for i in range(len(data3_en)):
        for j in range(len(data3_en[0][0,])):
            for k in range(len(data3_en[0])):
                if (float(j) == np.floor(p_en_x_3)).any():
                    if (k > np.min(np.floor(p_en_y_3[np.where(np.floor(p_en_x_3) == float(j))]))) and (k < np.max(np.floor(p_en_y_3[np.where(np.floor(p_en_x_3) == float(j))]))):
                        data3_en[i][k,j] = data3_en[i][k,j] + 1
                    else:
                        data3_en[i][k,j] = 0
                else:
                    data3_en[i][k,j] = 0                
    data1_ep = copy.deepcopy(data_slice_1_mc)
    for i in range(len(data1_ep)):
        for j in range(len(data1_ep[0][0,])):
            for k in range(len(data1_ep[0])):
                if (float(j) == np.floor(p_ep_x_1)).any():
                    if (k > np.min(np.floor(p_ep_y_1[np.where(np.floor(p_ep_x_1) == float(j))]))) and (k < np.max(np.floor(p_ep_y_1[np.where(np.floor(p_ep_x_1) == float(j))]))):
                        data1_ep[i][k,j] = data1_ep[i][k,j]
                    else:
                        data1_ep[i][k,j] = -1
                else:
                    data1_ep[i][k,j] = -1            
    data2_ep = copy.deepcopy(data_slice_2_mc)
    for i in range(len(data2_ep)):
        for j in range(len(data2_ep[0][0,])):
            for k in range(len(data2_ep[0])):
                if (float(j) == np.floor(p_ep_x_2)).any():
                    if (k > np.min(np.floor(p_ep_y_2[np.where(np.floor(p_ep_x_2) == float(j))]))) and (k < np.max(np.floor(p_ep_y_2[np.where(np.floor(p_ep_x_2) == float(j))]))):
                        data2_ep[i][k,j] = data2_ep[i][k,j]
                    else:
                        data2_ep[i][k,j] = -1
                else:
                    data2_ep[i][k,j] = -1                  
    data3_ep = copy.deepcopy(data_slice_3_mc)
    for i in range(len(data3_ep)):
        for j in range(len(data3_ep[0][0,])):
            for k in range(len(data3_ep[0])):
                if (float(j) == np.floor(p_ep_x_3)).any():
                    if (k > np.min(np.floor(p_ep_y_3[np.where(np.floor(p_ep_x_3) == float(j))]))) and (k < np.max(np.floor(p_ep_y_3[np.where(np.floor(p_ep_x_3) == float(j))]))):
                        data3_ep[i][k,j] = data3_ep[i][k,j]
                    else:
                        data3_ep[i][k,j] = -1
                else:
                    data3_ep[i][k,j] = -1  
    data1_myo = copy.deepcopy(data_slice_1_mc)
    for i in range(len(data1_myo)):
        data1_myo[i] = data1_ep[i] - data1_en[i]
    
    data2_myo = copy.deepcopy(data_slice_2_mc)
    for i in range(len(data2_myo)):
        data2_myo[i] = data2_ep[i] - data2_en[i]
    data3_myo = copy.deepcopy(data_slice_3_mc)
    for i in range(len(data3_myo)):
        data3_myo[i] = data3_ep[i] - data3_en[i]
    noise1 = {}
    for i in range(len(data1_myo)):
        noise1[i] = [data1_myo[i][np.where(data1_myo[i]<60000)],np.where(data1_myo[i]<60000)]
    noise2 = {}
    for i in range(len(data2_myo)):
        noise2[i] = [data2_myo[i][np.where(data2_myo[i]<60000)],np.where(data2_myo[i]<60000)]
    noise3 = {}
    for i in range(len(data3_myo)):
        noise3[i] = [data3_myo[i][np.where(data3_myo[i]<60000)],np.where(data3_myo[i]<60000)]
    for i in range(len(data1_myo)):
        data1_myo[i][np.where(data1_myo[i] > 60000)] = 0
    
    for i in range(len(data2_myo)):
        data2_myo[i][np.where(data2_myo[i] > 60000)] = 0
    
    for i in range(len(data3_myo)):
        data3_myo[i][np.where(data3_myo[i] > 60000)] = 0
    data_slice_1_mc_c = [1]*len(data_slice_1_mc)
    for i in range(len(data_slice_1_mc)):
        data_slice_1_mc_c[i] = data_slice_1_mc[i][cutsize[0]:cutsize[1],cutsize[2]:cutsize[3]]
    data_slice_2_mc_c = [1]*len(data_slice_2_mc)
    for i in range(len(data_slice_2_mc)):
        data_slice_2_mc_c[i] = data_slice_2_mc[i][cutsize[0]:cutsize[1],cutsize[2]:cutsize[3]]  
    data_slice_3_mc_c = [1]*len(data_slice_3_mc)
    for i in range(len(data_slice_3_mc)):
        data_slice_3_mc_c[i] = data_slice_3_mc[i][cutsize[0]:cutsize[1],cutsize[2]:cutsize[3]]
    data_1_myo_c = [1]*len(data1_myo)
    for i in range(len(data1_myo)):
        data_1_myo_c[i] = data1_myo[i][cutsize[0]:cutsize[1],cutsize[2]:cutsize[3]]
    data_2_myo_c = [1]*len(data2_myo)
    for i in range(len(data2_myo)):
        data_2_myo_c[i] = data2_myo[i][cutsize[0]:cutsize[1],cutsize[2]:cutsize[3]]
    data_3_myo_c = [1]*len(data3_myo)
    for i in range(len(data3_myo)):
        data_3_myo_c[i] = data3_myo[i][cutsize[0]:cutsize[1],cutsize[2]:cutsize[3]]
    signal_intensity1 = []
    time1 = []
    for i in range(len(noise1)):
        for j in range(len(noise1[0][0])):
            signal_intensity1.append(noise1[i][0][j])
            time1.append(i)
    signal_intensity1 = np.array(signal_intensity1)
    time1 = np.array(time1)   
    signal_intensity2 = []
    time2 = []
    for i in range(len(noise2)):
        for j in range(len(noise2[0][0])):
            signal_intensity2.append(noise2[i][0][j])
            time2.append(i)
    signal_intensity2 = np.array(signal_intensity2)
    time2 = np.array(time2)   
    signal_intensity3 = []
    time3 = []
    for i in range(len(noise3)):
        for j in range(len(noise3[0][0])):
            signal_intensity3.append(noise3[i][0][j])
            time3.append(i)
    signal_intensity3 = np.array(signal_intensity3)
    time3 = np.array(time3)
    bm1 = []
    bm_df_1 = []
    for i in range(len(ImagePostPoint)):
        bm1.append(np.vstack((noise1[i][0],noise1[i][1][0],noise1[i][1][1])))
    for i in range(len(bm1)):
        bm_df_1.append(pd.DataFrame(bm1[i].T,columns = ['signal_intensity','X','Y']))
    bm2 = []
    bm_df_2 = []
    for i in range(len(ImagePostPoint)):
        bm2.append(np.vstack((noise2[i][0],noise2[i][1][0],noise2[i][1][1])))
    for i in range(len(bm2)):
        bm_df_2.append(pd.DataFrame(bm2[i].T,columns = ['signal_intensity','X','Y']))
    bm3 = []
    bm_df_3 = []
    for i in range(len(ImagePostPoint)):
        bm3.append(np.vstack((noise3[i][0],noise3[i][1][0],noise3[i][1][1])))
    for i in range(len(bm3)):
        bm_df_3.append(pd.DataFrame(bm3[i].T,columns = ['signal_intensity','X','Y']))
    return bm_df_1,bm_df_2,bm_df_3,ImagePostContour,data_slice_1_mc,data_slice_2_mc,data_slice_3_mc,data_1_myo_c,data_2_myo_c,data_3_myo_c,cutsize